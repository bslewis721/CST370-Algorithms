/*
Title: sample.cpp
Abstract: This program displays Hello World and g++ version on screen
Author: Brandon Lewis
ID: 1066
Date: 4/21/2018
*/

#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World!\n";
    cout << "g++ version:" << __GNUC__ << endl;
    
    return 0;
}
